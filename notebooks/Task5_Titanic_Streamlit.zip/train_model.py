import joblib
import pandas as pd
from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier

BASE_DIR = Path(__file__).parent
DATA_PATH = BASE_DIR / "data" / "titanic.csv"
MODEL_PATH = BASE_DIR / "model.pkl"

features = ["Pclass", "Sex", "Age", "SibSp", "Parch", "Fare", "Embarked"]
target = "Survived"

df = pd.read_csv(DATA_PATH)

model_df = df[features + [target]].copy()
model_df["Age"] = model_df["Age"].fillna(model_df["Age"].median())
model_df["Fare"] = model_df["Fare"].fillna(model_df["Fare"].median())
model_df["Embarked"] = model_df["Embarked"].fillna(model_df["Embarked"].mode()[0])

X = pd.get_dummies(
    model_df[features],
    columns=["Sex", "Embarked"],
    drop_first=True,
    dtype=int
)
y = model_df[target].astype(int)

# Same split used in InternCircle Task 4.
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42, stratify=y
)

# Same Decision Tree configuration used in Task 4.
model = DecisionTreeClassifier(max_depth=4, random_state=42)
model.fit(X_train, y_train)

joblib.dump(model, MODEL_PATH)

print(f"Model saved to: {MODEL_PATH}")
print("Model input columns:")
print(X.columns.tolist())

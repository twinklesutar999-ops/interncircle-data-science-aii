import joblib
import pandas as pd
import streamlit as st
from pathlib import Path

st.set_page_config(
    page_title="Titanic Survival Predictor",
    page_icon="🚢",
    layout="centered"
)

MODEL_PATH = Path(__file__).parent / "model.pkl"

@st.cache_resource
def load_model():
    if not MODEL_PATH.exists():
        return None
    return joblib.load(MODEL_PATH)

model = load_model()

st.title("🚢 Titanic Survival Predictor")
st.write(
    "An interactive machine learning web app built with Streamlit "
    "using the Decision Tree classifier from InternCircle Task 4."
)

st.info(
    "This educational app predicts the model's output for the selected "
    "passenger characteristics. It is not a historical or causal explanation."
)

if model is None:
    st.error("model.pkl was not found.")
    st.markdown(
        "Add the trained **model.pkl** file to the same folder as `app.py`. "
        "Use the `train_model.py` helper to create it from `data/titanic.csv`."
    )
    st.stop()

st.sidebar.header("Passenger Details")

pclass = st.sidebar.selectbox(
    "Passenger Class",
    options=[1, 2, 3],
    index=2,
    help="1 = First class, 2 = Second class, 3 = Third class"
)

sex = st.sidebar.selectbox(
    "Sex",
    options=["female", "male"],
    index=1
)

age = st.sidebar.slider(
    "Age",
    min_value=0.0,
    max_value=80.0,
    value=30.0,
    step=1.0
)

sibsp = st.sidebar.slider(
    "Siblings / Spouses Aboard",
    min_value=0,
    max_value=8,
    value=0,
    step=1
)

parch = st.sidebar.slider(
    "Parents / Children Aboard",
    min_value=0,
    max_value=6,
    value=0,
    step=1
)

fare = st.sidebar.number_input(
    "Fare",
    min_value=0.0,
    max_value=600.0,
    value=32.0,
    step=1.0
)

embarked = st.sidebar.selectbox(
    "Port of Embarkation",
    options=["C", "Q", "S"],
    index=2,
    help="C = Cherbourg, Q = Queenstown, S = Southampton"
)

# The Task 4 notebook used:
# Pclass, Sex, Age, SibSp, Parch, Fare, Embarked
# with pd.get_dummies(..., drop_first=True).
# Therefore the expected model columns are:
# Pclass, Age, SibSp, Parch, Fare, Sex_male, Embarked_Q, Embarked_S

input_data = pd.DataFrame([{
    "Pclass": pclass,
    "Age": age,
    "SibSp": sibsp,
    "Parch": parch,
    "Fare": fare,
    "Sex_male": int(sex == "male"),
    "Embarked_Q": int(embarked == "Q"),
    "Embarked_S": int(embarked == "S"),
}])

st.subheader("Selected Passenger Details")
st.dataframe(
    pd.DataFrame({
        "Feature": [
            "Passenger Class", "Sex", "Age", "Siblings/Spouses",
            "Parents/Children", "Fare", "Embarkation"
        ],
        "Value": [
            pclass, sex.title(), age, sibsp, parch, fare, embarked
        ]
    }),
    use_container_width=True,
    hide_index=True
)

if st.button("🔮 Predict Survival", type="primary", use_container_width=True):
    try:
        prediction = int(model.predict(input_data)[0])

        st.subheader("Prediction")

        if prediction == 1:
            st.success("Prediction: Survived")
        else:
            st.warning("Prediction: Did not survive")

        if hasattr(model, "predict_proba"):
            probability = float(model.predict_proba(input_data)[0][1])
            st.metric("Model probability for Survived", f"{probability:.1%}")

    except Exception as exc:
        st.error(f"Prediction error: {exc}")
        st.write("Expected model input columns:")
        st.code(", ".join(input_data.columns))

st.caption("InternCircle Data Science & AI Internship — Task 5")

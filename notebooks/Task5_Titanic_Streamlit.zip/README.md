# InternCircle Task 5 — Titanic Survival Predictor

An interactive Streamlit machine learning web app for the InternCircle Data Science & AI Internship.

## Project Objective

Deploy the Decision Tree classifier developed in Task 4 as a simple interactive web application.

The app allows a user to enter passenger information and receive a real-time model prediction.

## Features

- Streamlit interface
- Model loading with `joblib`
- Interactive sliders and input controls
- Real-time prediction
- Survival probability when supported by the model
- Clear prediction output
- Simple portfolio-ready layout

## Machine Learning Model

The Task 4 model is a **Decision Tree Classifier**.

Target:

```text
Survived
```

Input features:

```text
Pclass
Sex
Age
SibSp
Parch
Fare
Embarked
```

The categorical variables `Sex` and `Embarked` are converted to dummy variables using the same `pd.get_dummies(..., drop_first=True)` approach used in Task 4.

## Repository Structure

```text
interncircle-data-science-ai/
│
├── app.py
├── model.pkl
├── train_model.py
├── requirements.txt
├── README.md
│
├── data/
│   └── titanic.csv
│
└── notebooks/
    ├── Titanic_EDA_Task_1.ipynb
    ├── Titanic_Visualization_Task_2.ipynb
    ├── Customer_Churn_Sales_Analysis.ipynb
    └── First_ML_Classifier_Task_4.ipynb
```

## How to Create `model.pkl`

Make sure your repository contains:

```text
data/titanic.csv
```

Then run:

```bash
python train_model.py
```

This creates:

```text
model.pkl
```

If you are using Google Colab, you can run:

```python
!python train_model.py
```

Alternatively, after running the Task 4 notebook, add this cell after training the model:

```python
import joblib

joblib.dump(model, "model.pkl")
print("model.pkl saved successfully")
```

Then place `model.pkl` in the project root beside `app.py`.

## Install Dependencies

```bash
pip install -r requirements.txt
```

## Run the App Locally

From the project root:

```bash
streamlit run app.py
```

Streamlit will open the application in your browser.

## Deploy with Streamlit Community Cloud

1. Push the complete project to GitHub.
2. Make sure `app.py`, `model.pkl`, and `requirements.txt` are in the repository.
3. Open Streamlit Community Cloud.
4. Choose **Create app**.
5. Select your GitHub repository.
6. Select the `main` branch.
7. Select `app.py` as the entrypoint.
8. Click **Deploy**.
9. Wait for the application to build.
10. Copy the generated `streamlit.app` URL.

## InternCircle Submission

After the Streamlit app is working:

1. Open the InternCircle internship dashboard.
2. Open **Task 5 — Streamlit / Gradio Interactive ML Web App**.
3. Click **Submit Task**.
4. Enter the requested project/repository details.
5. Add your GitHub repository link.
6. Add your deployed Streamlit app URL if the form asks for a live/demo link.
7. Add a short description such as:

> Developed an interactive Streamlit web app using the Decision Tree classifier from Task 4. The app loads the trained model with joblib, accepts passenger details through interactive inputs, and displays real-time Titanic survival predictions.

8. Attach screenshots if the submission form requests them.
9. Check that all required links are accessible.
10. Click the final **Submit** button.

## Important

Keep `model.pkl` in the GitHub repository if the app loads it directly from the project folder.

Do not upload passwords, API keys, or other private credentials.

## Task 5 Requirements Covered

- [x] Streamlit interface creation
- [x] Model loading with joblib
- [x] Interactive input controls
- [x] Real-time prediction display
- [x] End-to-end ML web application
